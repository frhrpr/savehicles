# GTA San Andreas vehicle reference pack

Reference files for building a new GTA San Andreas (PC, v1.0 / SilentPatch) car. All of them are unmodified game
files from a clean install, except `savibe_example/`, which is our own work.

## Contents
- `models/<name>.dff` / `.txd`: five stock sedans. Their game IDs:
  - 405 sentinel
  - 426 premier
  - 445 admiral
  - 466 glendale
  - 492 greenwoo (the Greenwood)

  Each model has its own TXD; textures the cars share live in `models/generic/vehicle.txd`.
- `models/generic/vehicle.txd`: the shared vehicle textures, such as `vehiclegeneric256`, `vehiclelights128` and
  `vehiclelightson128`.
- `models/generic/wheels.dff` / `.txd`: the tuning wheels (models 1025, 1073-1098). Stock cars carry their own wheel
  instead: an atomic called `wheel` under `wheel_rf_dummy`, which the game copies to the other three dummies.
- `data/`: the stock data files. Each sedan has one line in each of them:
  - `vehicles.ide` (cars section): ID, model, TXD, type, handling ID, game name, anims, class, frequency, flags,
    wheel model / scale.
  - `handling.cfg`: the format is documented in its header comment.
  - `carcols.dat`: colour pairs.
  - `carmods.dat`: which upgrade parts fit.
- `premier_structure.txt`: a dump of `premier.dff` showing its frames (names, parents, positions), atomics to
  geometries, materials and the chunk tree.
- `savibe_example/`: how we added a vehicle (ID 612) to our mod.
  - `vehicles.md`: our notes.
  - `dff.py`: a minimal RenderWare DFF reader/writer in Python. It round-trips byte for byte and edits geometry.
  - `stripes.py`: splits polygons to add racing stripes.
  - `make_img.py`: builds an IMG archive.
  - `savibe.ide`: our IDE file.

## The DFF format, briefly
- **Container:** RenderWare 3.6.0.3 (version stamp `0x1803FFFF`). The file is a Clump made of a FrameList, a
  GeometryList and Atomics (each atomic ties a frame to a geometry).
- **Frames:** these names are what the game looks for, so a new car has to reuse them.
  - Root frame: the car's model name.
  - Dummies: `chassis_dummy`, `wheel_lf/rf/lb/rb_dummy`, `door_lf/rf/lr/rr_dummy`, `bonnet_dummy`, `boot_dummy`,
    `bump_front_dummy`, `bump_rear_dummy`, `windscreen_dummy`.
  - Points: `headlights`, `taillights`, `exhaust`, `engine`, `petrolcap`, `ped_frontseat`, `ped_backseat`, `ped_arm`.
  - Upgrade mounts: `ug_*`.
- **Parts:** each one has an `_ok` and a `_dam` version. The game shows `_ok` until the part is damaged.
- **LOD:** `chassis_vlo` is the low-detail model.
- **Material colours:** the game recolours materials by their exact RGB:
  - (60,255,0) is body colour 1, (255,0,175) colour 2, (0,255,255) colour 3, (255,0,255) colour 4.
  - Lights (they switch on and off when damaged): front left (255,175,0), front right (0,255,200), rear left
    (185,255,0), rear right (255,60,0).
- **Extensions:** SA needs a few extensions on top of the base geometry:
  - Collision: an embedded COL3 in the clump's extension.
  - Night vertex colours, from Rockstar's extra-vertex-colour plugin.
  - Reflection and specular material effects (the env map).
  - 2dfx light entries.
  - The `Breakable` plugin on some atomics.
- **Usual tools:** modders normally use Blender with DragonFF, or 3ds Max with Kam's scripts, for DFF/COL; and
  TXD Workshop or Magic.TXD for TXD.

## Registering a new car in the game
- **IDs:** vanilla's car IDs are 400-611, and the cars section of the IDE is full. A new ID needs the fastman92 limit
  adjuster (IDE vehicle models limit, handling.cfg limit), or it has to replace an existing car.
- **Data lines:** add a line in each of the IDE, handling.cfg, carcols.dat and carmods.dat (optional). Engine sound
  needs the limit adjuster's vehicle audio loader, or the car has none.
- **Model files:** put the DFF and TXD into an IMG archive that gta.dat lists (`IMG MODELS\X.IMG`).
