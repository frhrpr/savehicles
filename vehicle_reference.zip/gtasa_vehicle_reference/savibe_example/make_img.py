"""Build our model archive E:\\gtasa-dev\\models\\savibe.img (loaded through data/gta.dat: IMG MODELS\\SAVIBE.IMG).

Its files come from the clean copy's gta3.img (vehicles we add start as copies of vanilla ones), edited on the way:
    geniusmb.dff  <- picador.dff + racing stripes on colour 3 (tools/stripes.py)   (612 geniusmb, Ryder's car after
                     the easter egg; data/savibe.ide)

IMG v2: "VER2", entry count, 32-byte entries (offset and size in 2048-byte sectors, name[24]), files sector-aligned.
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sa_anims  # noqa: E402
import stripes  # noqa: E402

CLEAN = "/mnt/e/gtasa-mta/models/gta3.img"
OUT = "/mnt/e/gtasa-dev/models/savibe.img"
COPIES = {"geniusmb.dff": "picador.dff"}
EDITS = {"geniusmb.dff": "stripes"}
SECTOR = 2048


def write_img(path, files):
    """files: [(name, bytes)]"""
    header = 8 + 32 * len(files)
    pos = (header + SECTOR - 1) // SECTOR
    entries, blobs = [], []
    for name, data in files:
        assert len(name) < 24, name
        sectors = (len(data) + SECTOR - 1) // SECTOR
        entries.append(struct.pack("<IHH24s", pos, sectors, 0, name.encode("ascii")))
        blobs.append(data + b"\0" * (sectors * SECTOR - len(data)))
        pos += sectors
    head = b"VER2" + struct.pack("<I", len(files)) + b"".join(entries)
    head += b"\0" * ((header + SECTOR - 1) // SECTOR * SECTOR - len(head))
    data = head + b"".join(blobs)
    if os.path.exists(path) and open(path, "rb").read() == data:
        return False  # unchanged (the game may have it open)
    with open(path, "wb") as f:
        f.write(data)
    return True


def main():
    wanted = {v: k for k, v in COPIES.items()}
    found = {}
    for name, data in sa_anims.img_entries(CLEAN):
        if name.lower() in wanted:
            found[wanted[name.lower()]] = data
    missing = set(COPIES) - set(found)
    assert not missing, missing
    for name, edit in EDITS.items():
        data = found[name]
        size = struct.unpack_from("<I", data, 4)[0] + 12  # the clump (an IMG entry is padded to its sectors)
        if edit == "stripes":
            found[name], counts = stripes.stripes(data[:size])
            print(f"{name}: stripes cut ({sum(counts.values())} stripe polygons: "
                  + ", ".join(f"{k} {v}" for k, v in sorted(counts.items())) + ")")
    changed = write_img(OUT, sorted(found.items()))
    print(f"models/savibe.img: {len(found)} files ({', '.join(sorted(found))}){'' if changed else ', unchanged'}")


if __name__ == "__main__":
    main()
