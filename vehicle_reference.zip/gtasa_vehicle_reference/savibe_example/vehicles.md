# Vehicles we add

How (2026-10-16, first one: 612 geniusmb):
- ID: free IDs after vanilla's 400-611 (612, 613, 614 free; 615+ are map objects). fastman92 limit adjuster makes room:
  `[IDE LIMITS] Vehicle Models` (vanilla's cars section is full at 212), `[HANDLING.CFG LIMITS]` (210 standard lines),
  `[ADDONS] Enable vehicle audio loader` (engine sounds etc. per model from data/gtasa_vehicleAudioSettings.cfg; a
  vehicle without a line there would have none). See game_files/fastman92limitAdjuster_GTASA.ini.
- Data (game_data/, copies of the clean files with our lines): `savibe.ide` (our `cars` section; loaded through
  `gta.dat` `IDE DATA\SAVIBE.IDE`), `handling.cfg`, `carcols.dat`, `carmods.dat` (mod shop / add_vehicle_mod parts),
  `gtasa_vehicleAudioSettings.cfg`, `gta.dat` (`IMG MODELS\SAVIBE.IMG`).
- Model files: models/savibe.img, built by tools/make_img.py from the clean gta3.img (a DFF needs its own name: two
  IDs can't share one; TXDs can be shared, e.g. geniusmb uses picador.txd). Later tools can edit models on the way.
- Name: the IDE's game name is a text key (GENIUS in text/savibe.fxt).

## 612 geniusmb (the Geniusmobile)
Ryder's car after the easter egg in Ryder (012). picador.dff with racing stripes (tools/stripes.py, run by
tools/make_img.py): the colour-1 polygons of chassis, chassis_vlo, bonnet_ok/dam, boot_ok/dam (tailgate) facing up /
sideways are split along the stripes' edges (|x| 0.05..0.29 m, front to back); the pieces inside get a copy of their
material with colour 3's placeholder (0,255,255). Not the bed (colour 2), not the underside. Tool library:
tools/dff.py (chunk tree read / write, byte-identical round trip; geometry struct; bin mesh rebuilt as triangle
lists). carcols.dat car4: geniusmb 3,36,1,0 (red, near-black bed, white stripes). Handling GENIUSMB: a sports ute
(mass 1450, drag 2.4, centre of mass -0.15, traction 0.85 / 0.80, top speed 200, accel 32, inertia 8, RWD petrol,
brakes 11, steering 33, stiffer and lower suspension) vs PICADOR (1600, 2.7, 0.0, 0.65 / 0.70, 165, 25, 20, RWD diesel,
8.5, 35, soft). Colours 3 / 36 / 1 (red, the bed near black, white stripes). Engine sound: Buffalo's. Picador's upgrade list.
Not in traffic (frequency 0, no car group).
